CSC 210: Final Project

University of Rochester Project Website
Built by Adham Mashaly, Jessica Zhang, and Nicholas (Tai) Thurber

- Confirmation emails are sent from "rochesterprojects@gmail.com"
    - Account password is "csc210final" and is posted in the "emailAuth.py" file

- Accounts already registered
    - Rocky (Project Leader)
        - Email: nicholastaithurber@gmail.com
        - Password: rochester
    - Nicholas Thurber (project administrator)
        - Email: nthurber@u.rochester.edu
        - Password: dog
    -Adham Mashaly(Project Admin)
	-Email: amashaly@u.rochester.edu
	-Password: adham